# program to find the hcf of two given no 

a=int(input("enter no: "))
b=int(input("enter no: "))

while a % b !=0:
    rem= a % b
    a = b
    b =rem
print(f"your HCF is : {b}")