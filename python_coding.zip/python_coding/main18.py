# program to print the all possible  combination from the digit
flag=0
a=int(input("enter no:"))
b=int(input("enter no:"))
for i in range(a,b):
    for j in range(a,b):
        if (i==j):
            print(f"combination : {i},{j}")
    flag=flag+1
print(f"no of combination: {flag}")
        
            
            
    
