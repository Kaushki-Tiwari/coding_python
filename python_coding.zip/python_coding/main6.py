# Python program to check if the given 3 angles can form a triangle or not.

a=int(input("enter a angle: "))
b=int(input("enter a angle: "))
c=int(input("enter a angle: "))

if (a+b+c )== 180:
    print("tringle")

else:
    print("tringle not possible")
