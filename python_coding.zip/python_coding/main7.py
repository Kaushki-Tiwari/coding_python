# To calculate Profit or Loss for given selling and cost price.
cp=int(input(" enter a no : "))
sp=int(input(" enter a no : "))

if cp<sp:
    profit=sp-cp
    print("profit",profit)

else:
    loss=cp-sp
    print("loss",loss)

# Python program to calculate Simple Interest.
    
p = int(input("enter principal :"))
r = int(input("enter rate :"))
t = int(input("enter time :"))

SI=(p*r*t)/100
print(SI)