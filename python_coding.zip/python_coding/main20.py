# write a python code to explain types of constructor
# take a class employee and have data members as id name and salary
# explain default constructor and paramaterized constructor 

class Employee :
    def __init__(self,n,o,s,id):
        self.name=n
        self.occ=o
        self.salary=s
        self.id=id
        print(f"{self.name} is a {self.occ} and its salary is {self.salary}, id is {self.id}")

Employee("Kaushki","developer",35000,29639)


