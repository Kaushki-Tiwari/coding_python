# Swap 2 variables in Python using third variable

a= int(input("enter a no : "))
b= int(input("enter a no:  "))

temp =a
a=b
b= temp
print(a)
print(b)

#Swap 2 variables in Python  without using third variable

a= int(input("enter a no : "))
b= int(input("enter a no:  "))

a=a+b
b=a-b
a=a-b
print(a)
print(b)
