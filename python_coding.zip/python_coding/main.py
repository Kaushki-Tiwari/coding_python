# Python program to find the largest among 3 numbers entered by the user.

A=int(input("ENTER A NO:"))
B=int(input("enter a no:"))
C=int(input("enter a no:"))

max=A
if max<B:
    max=B
if max<C:
    max=C
print(max)