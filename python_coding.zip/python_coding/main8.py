# Calculate Volume of Cylinder

radius=int(input ( " enter a no :"))
height=int(input ( " enter a no :"))

voloume=3.14*(radius**2)*height
print(voloume)