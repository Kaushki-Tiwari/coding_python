# calculate LCM of two number

a=int(input("enter no:"))
num_1= a
b=int(input("enter no:"))
num_2= b

while num_1 % num_2 !=0:
    rem= num_1 % num_2
    num_1=num_2
    num_2=rem
    
hcf=num_2
lcm=(a*b)/hcf
print(f"your lcm: {lcm}")