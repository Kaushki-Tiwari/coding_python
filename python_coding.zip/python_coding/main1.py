# Python program to convert temperature from celcius to fahrenheit.

temp = int(input("enter temp in celcius: "))

fahrenheit=(temp * 18)+32
print(fahrenheit)