# Python program to check if a given number is Armstrong number or not.

no= int(input ("enter a no : "))

a=no % 10
no1=no //10
b=no1 % 10
c=no1//10

cube_sum=(a**3)+(b**3)+(c**3)
print(cube_sum)

if no==cube_sum:
    print("Armstrong no")

else :
    print("not Armstrong no ")


# Narcissictic number






user_input=int(input("enter a no : "))
no =user_input
a= no % 10
num1=no//10
b=num1%10
num2=num1//10
c=num2%10
d=num2//10

sum=(a**4)+(b**4)+(c**4)+(d**4)

if sum ==no:
    print("narcissictic no")

else:
    print("not narcissictic no ")
