# Python program to print first 25 Odd numbers.

flag=0
i= 1
while True:
    if i %2 !=0:
        print (i)
        flag=flag+1

    if flag==25:
        break
    i+=1