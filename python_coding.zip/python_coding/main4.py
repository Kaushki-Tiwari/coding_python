# Python program to check if a number is even or odd.(User input)

no = int(input("enter a no: "))

if no%2==0:
    print(f"{no} is even")

else:
    print(f"{no} is odd")

# Leap year program 
    
year = int(input("enter a year : "))

if (year %4== 0 and year % 100 != 0 or year % 400 ==0):
    print("leap year")
else:
    print("not leap year ")