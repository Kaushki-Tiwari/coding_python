# Python code to add the digits of the number entered by the user

a=int(input("enter no:"))

b=a%10
num1=a//10
c=num1%10
num2=num1//10
d=num2%10
num3=num2//10
print("sum: " ,(b+c+d+num3))

# Reverse digits using Python

num=int(input ("enter a no : "))

a=num% 10
num1=num//10
b=num1%10
num2=num1//10
c=num2%10
num3=num2//10
rev=(1000 * a) +(100*b) +(10*c) +num3
print("reverse: " ,rev)



