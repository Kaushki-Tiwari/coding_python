# How to write a menu driven program in Python.

user_input=int(input("welcome ! what would u like to do: 1.convert cm to inch 2.convert km to miles 3.convert usd to inr  "))

if user_input==1:
    cm=float(input("enter value in cm :"))
    inch= cm *0.394
    print(inch)

elif user_input==2:
    km=float(input("enter value in km :"))
    miles= km *0.621
    print(miles)

elif user_input==3:
    usd=float(input("enter usd :"))
    inr= usd*82.88
    print(inr)

else:
    print("exit")
     