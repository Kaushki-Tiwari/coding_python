# Python program to print the sum of first n numbers.

no =int(input(" enter a no :"))

sum=no*(no+1)/2
print(sum )

# Python program to multiply two numbers without using the '*' operator.

a=int(input("enter no : "))
b=int(input("enter no : "))
sum=0
for i in range (0,a):
    sum= sum + b
    print(sum)

# Python program to find the Factorial of a given number.
    
no=int(input("enter no :"))
i=1
if no >= 1:
    while no >= 1 :
        i=i*no
        no=no-1
    print(i)


