# Python program to find the euclidean distance .

x1=int(input("enter a no : "))
y1=int(input("enter a no : "))
x2=int(input("enter a no : "))
y2=int(input("enter a no : "))

d=((x1-y1)**2 + (y1-y2)**2 )**0.5
print(d)