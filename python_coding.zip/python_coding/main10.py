# Python program to find the sum of the square of a given number

no =  int(input("enter a no :"))

a= no%10
num1=no //10
c=num1% 10
num2=num1//10
d=num2%10
num3=num2//10

sum_square=(a)**2+(c)**2+(d)**2+(num3)**2
print(sum_square)