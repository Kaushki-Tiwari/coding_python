# Python program to check a number is Prime or not.

num= int(input("enter no : "))

if num==2:
    print("prime no")

elif(num>=2):
    for i in range(2,num):
        if num%i==0:
            print("not prime")
            break
        else :
            print("prime")
            break
        
else:
    print("not prime")


