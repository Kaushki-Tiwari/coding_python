# Python program to check if a given number is divisible by both 3 & 6.

no =int (input("enter a no : "))

if no%3==0 and no % 6==0 :
    print("divisible by 3 & 6")

else:
    print("not divisible")