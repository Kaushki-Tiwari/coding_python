# calculate population

flag=0
a=10000
print(f"present population = {a}")
print(f'population decrease by 10% per year')

while True:
    b=(a)- ((a* 10)/100)
    a=b
    print(int(b))
    flag=flag+1
    
    if flag==9:
        break